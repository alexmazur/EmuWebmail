#!/bin/sh

# HM 10/27/00
# Make a single module from a tarball
# PARAMS:
#   1: Module to make, without the tar.gz extension
#   2: the INST_LIB
#   3: the INST_ARCHLIB
#

MODULE=$1

gzip -dc $MODULE.tar.gz | tar xf -
cd $MODULE
if [ $MODULE = 'Net_SSLeay.pm-1.30' ]; 
then
perl Makefile.PL
make > /dev/null
else
perl Makefile.PL INST_LIB=$2 INST_ARCHLIB=$3 > /dev/null
make > /dev/null
fi