#!/usr/bin/perl

use Cwd;
use strict;
use Config;

# Unbuffer our output
$|=1;

# Config
my $modlist = 'modules-sorted.txt';
my $tmpdir = cwd.'/built_modules';

open(MODIN, $modlist) or die "Unable to open file '$modlist': $!\n";
my @modules =  map { s/^\s+//; s/\s+$//; $_ } grep { !/^\s*#/ } <MODIN>;
close (MODIN);

# Create and set our install path
mkdir($tmpdir, 0775);

my $INST_LIB = $tmpdir;
my $INST_ARCHLIB = "$tmpdir/$Config{'archname'}";

$ENV{PERL5LIB} = $tmpdir;

opendir(MODDIR, '.') or die "Unable to open current directory for reading!\n";
my %files = map { $_ =~ s/\.tar\.gz$//; $_ => 1 } grep { /\.tar\.gz$/ } readdir(MODDIR);
closedir(MODDIR);

foreach my $m (@modules) {
   foreach my $f (keys %files) {
      if ($f =~ /^\Q$m\E-(.+?)+$/) {
         print "Building $f ... ";
         delete $files{$f};
         system('./instmod.sh', $f, $INST_LIB, $INST_ARCHLIB);
         print "Done.\n";
         last;
      }
   }
}

closedir(MODDIR);

print "\nAll modules built!\n";

if ($ARGV[0]) {
   print "Copying modules to $ARGV[0] ... ";
   system("mkdir -p $ARGV[0]");
   system("cp -R $tmpdir/* $ARGV[0]");
   print "Done.\n";
}
